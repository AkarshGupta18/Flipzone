import java.util.ArrayList;
import java.util.Scanner;

public class Category {
    public float id;
    public String name;
    public ArrayList<Product> list_of_products = new ArrayList<>();

    void add_product() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter the product ID:- ");
        float id = sc.nextFloat();
        String aa = sc.nextLine();
        System.out.println("Please enter the product name:- ");
        String name = sc.nextLine();

        System.out.println("Please enter the product price:- ");
        float price = sc.nextFloat();

        System.out.println("Please enter the Quantity of product in stock:- ");
        int quant = sc.nextInt();
        String ww = sc.nextLine();

        System.out.println("Please enter any other information about the product:- ");
        String info = sc.nextLine();

        Product new_product = new Product();
        new_product.name = name;
        new_product.id = id;
        new_product.set_price(price);
        new_product.info = info;
        new_product.quantity = quant;
        list_of_products.add(new_product);
        Flipzon.list_of_every_product.add(new_product);
    }
}
