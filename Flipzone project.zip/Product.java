public class Product extends Category {
    public int quantity;
    private float price;
    public String info = "";
    public float disc_elite = 10;
    public float disc_prime = 5;
    public float disc_normal = 0;

    public Product p1 = null;
    public Product p2 = null;

    void set_price(float price) {
        this.price = price;
    }

    float get_price() {
        return this.price;
    }

    void display_info() {
        if(this.name.equals("Deal")){
            System.out.println("Name - " + this.name + "\n" +
                    "ID - " + this.id + "\n" +
                    "Normal Price - " + this.normal_deal_price +"\n" +
                    "Elite Price - "+ this.elite_deal_price+"\n" +
                    "Prime Price - "+ this.prime_deal_price);
        }
        else{
            System.out.println("Name - " + this.name + "\n" +
                    "ID - " + this.id + "\n" +
                    "Price - " + this.price);
        }

        if (!info.equals("")) {
            System.out.println("Info- " + this.info);
        }
    }
    public float normal_deal_price;
    public float elite_deal_price;
    public float prime_deal_price;

    float get_elite_price() {
        return price - price * disc_elite / 100;
    }

    float get_prime_price() {
        return price - price * disc_prime / 100;
    }

    float get_normal_price() {
        return price - price * disc_normal / 100;
    }
}
