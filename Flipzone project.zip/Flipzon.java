import java.util.ArrayList;

public interface Flipzon {
    public ArrayList<Product> list_of_every_product = new ArrayList<>();
    public ArrayList<Product> list_of_deals = new ArrayList<>();
    public ArrayList<User> list_of_users = new ArrayList<>();

    void add_category();

    void add_product();

    void add_giveaway();

    void set_discount();
}