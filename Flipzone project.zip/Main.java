//Username - Yajat Gupta
//Password - Yajat123



import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Admin Yajat = new Admin();
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to Flipzon App !!");
        while (true) {
            System.out.println("1) Enter as Admin\n" +
                    "2) Explore the Product Catalog\n" +
                    "3) Show Available Deals\n" +
                    "4) Enter as Customer\n" +
                    "5) Exit the Application");

            int user_input1 = sc.nextInt();
            String w = sc.nextLine();

            if (user_input1 == 3) {
                if (Flipzon.list_of_deals.size() > 0) {
                    for (int i = 0; i < Flipzon.list_of_deals.size(); i++) {
                        Flipzon.list_of_deals.get(i).display_info();
                        System.out.println();
                    }
                } else {
                    System.out.println("No deals right now :(, Check regularly for deals.");
                }
            } else if (user_input1 == 1) {
                System.out.println("Enter your username:- ");
                String username = sc.nextLine();
                System.out.println("Enter your Password:- ");
                String password = sc.nextLine();

                if (Objects.equals(username, Yajat.username) && Objects.equals(password, Yajat.password)) {
                    System.out.println("Welcome Yajat!");
                    while (true) {
                        System.out.println("1) Add category\n" +
                                "2) Delete category\n" +
                                "3) Add Product\n" +
                                "4) Delete Product\n" +
                                "5) Set Discount on Product\n" +
                                "6) Add giveaway deal\n" +
                                "7) Back");
                        int user_input2 = sc.nextInt();
                        String w1 = sc.nextLine();
                        if (user_input2 == 1) {
                            Yajat.add_category();
                        } else if (user_input2 == 2) {
                            Yajat.delete_category();
                        } else if (user_input2 == 4) {
                            Yajat.delete_product();
                        } else if (user_input2 == 3) {
                            Yajat.add_product();
                        } else if (user_input2 == 6) {
                            Yajat.add_giveaway();
                        } else if (user_input2 == 5) {
                            Yajat.set_discount();
                        } else {
                            break;
                        }
                    }
                } else {
                    System.out.println("Wrong Password/Username!");
                }
            } else if (user_input1 == 2) {
                for (int i = 0; i < Flipzon.list_of_every_product.size(); i++) {
                    Flipzon.list_of_every_product.get(i).display_info();
                    System.out.println();
                }
            } else if (user_input1 == 4) {
                while (true) {
                    System.out.println("1) Sign up\n" +
                            "2) Log in\n" +
                            "3) Back");
                    int user_input3 = sc.nextInt();
                    String w2 = sc.nextLine();
                    if (user_input3 == 1) {
                        System.out.println("Enter Name:- ");
                        String name = sc.nextLine();
                        System.out.println("Enter Password:- ");
                        String pass = sc.nextLine();
                        System.out.println("Enter Mobile number:- ");
                        String mob = sc.nextLine();
                        User new_user = new User();
                        new_user.username = name;
                        new_user.setPassword(pass);
                        new_user.mobile = mob;
                        Flipzon.list_of_users.add(new_user);
                        System.out.println("Registered!!");
                    } else if (user_input3 == 2) {
                        System.out.println("Enter Name:- ");
                        String name = sc.nextLine();
                        System.out.println("Enter Password:- ");
                        String pass = sc.nextLine();
                        for (int h = 0; h < Flipzon.list_of_users.size(); h++) {
                            if (Flipzon.list_of_users.get(h).get_password().equals(pass)) {
                                User login_user = new User();
                                login_user = Flipzon.list_of_users.get(h);
                                System.out.println("Welcome " + login_user.username + "!");
                                while (true) {
                                    System.out.println("1) browse products\n" +
                                            "2) browse deals\n" +
                                            "3) add a product to cart\n" +
                                            "4) add products in deal to cart\n" +
                                            "5) view coupons\n" +
                                            "6) check account balance\n" +
                                            "7) view cart\n" +
                                            "8) empty cart\n" +
                                            "9) checkout cart\n" +
                                            "10) upgrade customer status\n" +
                                            "11) Add amount to wallet\n" +
                                            "12) back");
                                    int user_input4 = sc.nextInt();
                                    String w3 = sc.nextLine();
                                    if (user_input4 == 1) {
                                        for (int k = 0; k < Yajat.list_of_categories.size(); k++) {
                                            if(Yajat.list_of_categories.get(k).list_of_products.size()==0){
                                                Yajat.list_of_categories.remove(k);
                                                k= k-1;
                                            }else{
                                                System.out.println("The products in " + Yajat.list_of_categories.get(k).name
                                                        + " category is:- ");
                                                for (Product product : Yajat.list_of_categories.get(k).list_of_products) {

                                                    product.display_info();
                                                    System.out.println();
                                                }
                                            }
                                        }
                                    } else if (user_input4 == 2) {
                                        for (Product product : Flipzon.list_of_deals) {
                                            if(product.p1==null || product.p2 == null){
                                                int a = 12;
                                            }else{
                                            product.display_info();
                                            System.out.println();}
                                        }
                                    } else if (user_input4 == 3) {
                                        login_user.add_to_cart();
                                    } else if (user_input4 == 4) {
                                        login_user.add_deal_to_cart();
                                    } else if (user_input4 == 5) {
                                        System.out.println("You have following discount coupons:- ");
                                        for (int y = 0; y < login_user.coupons.size(); y++) {
                                            System.out.println(login_user.coupons.get(y) + "%");

                                        }
                                        System.out.println();
                                    } else if (user_input4 == 6) {
                                        login_user.get_walletBalance();
                                    } else if (user_input4 == 7) {
                                        int p = 0;
                                        for (Product product : login_user.cart) {

                                            product.display_info();
                                            System.out.println("Quantity - " + login_user.quantities.get(p));
                                            p = p + 1;
                                            System.out.println();
                                        }
                                    } else if (user_input4 == 8) {
                                        login_user.empty_cart();
                                        login_user.quantities.clear();
                                    } else if (user_input4 == 9) {
                                        login_user.check_out();
                                    } else if (user_input4 == 10) {
                                        login_user.setStatus();
                                    } else if (user_input4 == 11) {
                                        System.out.println("Enter Money you want to add:- ");
                                        int money = sc.nextInt();
                                        String w5 = sc.nextLine();
                                        login_user.add_money(money);
                                    } else {
                                        break;
                                    }
                                }
                            } else {
                                System.out.println("Wrong Password!!");
                            }
                        }
                    } else {
                        break;
                    }
                }

            } else {
                break;
            }
        }
    }
}