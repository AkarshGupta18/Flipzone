import java.util.*;

public class User {
    Scanner sc = new Scanner(System.in);
    public String username;
    private String password;
    public String mobile;
    public ArrayList<Product> cart = new ArrayList<>();
    public ArrayList<Integer> quantities = new ArrayList<>();
    // private ArrayList<Giveaway_deals> cart_deal = new ArrayList<>();
    public ArrayList<Integer> coupons = new ArrayList<>();
    private String Status = "Normal";
    private float wallet_balance = 1000;
    private float cart_amount;

    void setStatus() {
        System.out.println("The current status is " + this.Status);
        System.out.println("Choose new status: \n" +
                "(1). Elite\n" +
                "(2). Prime");

        int new_status = sc.nextInt();
        String gg = sc.nextLine();
        if (new_status == 1 && !Objects.equals(this.Status, "Elite")) {
            if (this.wallet_balance >= 300) {
                this.wallet_balance = this.wallet_balance - 300;
                this.Status = "Elite";
                System.out.println("Status upgraded to Elite and Balance in your wallet = " + wallet_balance);
            } else {
                System.out.println("Insufficient balance.");
            }
        } else if (new_status == 2 && !Objects.equals(this.Status, "Prime") && !Objects.equals(this.Status, "Elite")) {
            if (this.wallet_balance >= 200) {
                this.wallet_balance = this.wallet_balance - 200;
                this.Status = "Prime";
                System.out.println("Status upgraded to Prime and Balance in your wallet = " + wallet_balance);
            } else {
                System.out.println("Insufficient balance.");
            }
        } else {
            System.out.println("You are already at a higher or same Status, Please choose a higher Status.");
            
        }

    }

    void get_walletBalance() {
        System.out.println("The current balance is " + this.wallet_balance);
    }

    void add_to_cart() {
        System.out.println("Please enter the desired Product's ID:- ");
        float p_id = sc.nextFloat();
        System.out.println("Please enter the quantity you want to buy:- ");
        int quantity = sc.nextInt();
        String gg = sc.nextLine();
        for (int i = 0; i < Flipzon.list_of_every_product.size(); i++) {
            if (Flipzon.list_of_every_product.get(i).id == p_id) {

                if (quantity <= Flipzon.list_of_every_product.get(i).quantity) {
                    cart.add(Flipzon.list_of_every_product.get(i));
                    quantities.add(quantity);
                    Flipzon.list_of_every_product.get(i).quantity = Flipzon.list_of_every_product.get(i).quantity
                            - quantity;
                    cart_amount = cart_amount + quantity * Flipzon.list_of_every_product.get(i).get_price();
                } else {
                    System.out.println("Insufficient quantity in our Stock, Sorry!");
                }
                break;
            }
        }
    }

    int flag = 0;

    void add_deal_to_cart() {
        flag = 1;
        System.out.println("Please enter the desired Deal's ID:- ");
        float p_id = sc.nextFloat();
        String gg = sc.nextLine();
        for (int i = 0; i < Flipzon.list_of_every_product.size(); i++) {
            if (Flipzon.list_of_every_product.get(i).id == p_id) {

                if (Flipzon.list_of_every_product.get(i).p1.quantity >= 1
                        && Flipzon.list_of_every_product.get(i).p2.quantity >= 1) {
                    cart.add(Flipzon.list_of_every_product.get(i));
                    quantities.add(1);
                    cart_amount = cart_amount + 1 * Flipzon.list_of_every_product.get(i).get_price();
                } else {
                    System.out.println("Insufficient quantity in our Stock, Sorry!");
                }
                break;
            }
        }
    }

    void empty_cart() {
        this.cart.clear();
        cart_amount = 0;
        flag = 0;
    }

    void check_out() {
        System.out.println("These are the product/deal details in your cart:- ");
        int coup_flag = 0;
        float disc_price = 0;
        int i = 0;
        for (Product product : cart) {

            product.display_info();
            System.out.println(
                    "Price of " + quantities.get(i) + " quantity/ies is " + product.get_price() * quantities.get(i));
            if (Objects.equals(this.Status, "Normal")) {
                float coupon_price = 10000000;
                if (coupons.size() != 0) {
                    coupons.sort(Collections.reverseOrder());
                    coupon_price = product.get_price() - product.get_price() * coupons.get(0) / 100;
                }
                if (coupon_price < product.get_normal_price() && !product.name.equals("Deal")) {
                    disc_price = disc_price + coupon_price * quantities.get(i);
                    coup_flag = 1;
                    System.out
                            .println("As you got max disc using a coupon, we applied " + coupons.get(0) + "% coupon.");
                } else {

                    if (product.name.equals("Deal")) {
                        disc_price = disc_price + product.normal_deal_price;
                    } else {
                        disc_price = disc_price + product.get_normal_price() * quantities.get(i);
                    }
                }
                System.out.println("Discount - " + product.disc_normal);
            } else if (Objects.equals(this.Status, "Elite")) {
                float coupon_price = 10000000;
                if (coupons.size() != 0) {
                    coupons.sort(Collections.reverseOrder());
                    coupon_price = product.get_price() - product.get_price() * coupons.get(0) / 100;
                }
                if (coupon_price < product.get_elite_price() && !product.name.equals("Deal")) {
                    disc_price = disc_price + coupon_price * quantities.get(i);
                    coup_flag = 1;
                    System.out
                            .println("As you got max disc using a coupon, we applied " + coupons.get(0) + "% coupon.");
                } else {
                    if (product.name.equals("Deal")) {
                        disc_price = disc_price + product.elite_deal_price;
                    }
                    {
                        disc_price = disc_price + product.get_elite_price() * quantities.get(i);
                    }
                }
                System.out.println("Discount - " + product.disc_elite);
            } else {
                float coupon_price = 10000000;
                if (coupons.size() != 0) {
                    coupons.sort(Collections.reverseOrder());
                    coupon_price = product.get_price() - product.get_price() * coupons.get(0) / 100;
                }
                if (coupon_price < product.get_prime_price() && !product.name.equals("Deal")) {
                    disc_price = disc_price + coupon_price * quantities.get(i);
                    coup_flag = 1;
                    System.out
                            .println("As you got max disc using a coupon, we applied " + coupons.get(0) + "% coupon.");
                } else {
                    if (product.name.equals("Deal")) {
                        disc_price = disc_price + product.prime_deal_price;
                    }
                    {
                        disc_price = disc_price + product.get_prime_price() * quantities.get(i);
                    }
                }
                System.out.println("Discount - " + product.disc_prime);
            }
            System.out.println();
            i = i + 1;
        }
        if (coupons.size() != 0 && coup_flag == 1) {
            coupons.remove(0);
        }
        System.out.println("Discounted price is - " + disc_price);
        float total_price;
        if (Objects.equals(Status, "Elite")) {
            total_price = disc_price + 100;
            System.out.println("Delivery price is 100, total price is " + total_price);
        } else if (Objects.equals(Status, "Prime")) {
            total_price = disc_price + 100 + cart_amount * 2 / 100;
            System.out.println(
                    "Delivery price is " + 100 + "+" + cart_amount * 2 / 100 + ", total price is " + total_price);
        } else {
            total_price = disc_price + 100 + cart_amount * 5 / 100;
            System.out.println(
                    "Delivery price is " + 100 + "+" + cart_amount * 5 / 100 + ", total price is " + total_price);
        }

        Random random = new Random();
        if (wallet_balance >= total_price) {
            wallet_balance = wallet_balance - total_price;
            System.out.println("ORDER PLACED!!");
            if (Objects.equals(Status, "Prime")) {
                System.out.println("It will be delivered in 3-6 days.");
                if (total_price >= 5000) {
                    int number_of_coupons = 2 + random.nextInt(2);
                    for (int y = 0; y < number_of_coupons; y++) {
                        int percent = 5 + random.nextInt(11);
                        System.out.println("Congratulations! you won a coupon of " + percent + "%.");
                        coupons.add(percent);
                    }
                }
            } else if (Objects.equals(Status, "Elite")) {
                System.out.println("It will be delivered within 2 days.");
                if (total_price >= 5000) {
                    int number_of_coupons = 3 + random.nextInt(2);
                    for (int y = 0; y < number_of_coupons; y++) {
                        int percent = 5 + random.nextInt(11);
                        System.out.println("Congratulations! you won a coupon of " + percent + "%.");
                        coupons.add(percent);
                    }
                }
            } else {
                System.out.println("It will be delivered in 7-10 days.");
            }
            this.cart.clear();
            flag = 0;
        } else {
            System.out.println("INSUFFICIENT BALANCE.");
        }

    }

    void add_money(int money) {
        wallet_balance = wallet_balance + money;
    }

    String get_password() {
        return password;
    }

    void setPassword(String Pass) {
        this.password = Pass;
    }

}