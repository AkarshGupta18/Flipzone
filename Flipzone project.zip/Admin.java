import java.util.ArrayList;
import java.util.Scanner;

public class Admin implements Flipzon {
    Scanner sc = new Scanner(System.in);
    final String username = "Yajat Gupta";
    final String password = "Yajat123";

    public ArrayList<Category> list_of_categories = new ArrayList<>();
    // private ArrayList<Giveaway_deals> list_of_deals = new ArrayList<>();

    @Override
    public void add_category() {

        System.out.println("Please enter the Category ID:- ");
        float id = sc.nextFloat();
        String ww1 = sc.nextLine();

        for (int i = 0; i < list_of_categories.size(); i++) {
            if (list_of_categories.get(i).id == id) {
                System.out.println("Dear Admin, this category id is already in use, please use a different id!");
                id = sc.nextFloat();
                i = -1;
            }
        }

        System.out.println("Please enter the Category name:- ");
        String name = sc.nextLine();

        Category new_category = new Category();
        new_category.id = id;
        new_category.name = name;
        list_of_categories.add(new_category);

        // System.out.println("Add Product:");
        new_category.add_product();
    }

    @Override
    public void add_product() {
        System.out.println("Please enter the category id:- ");
        int category_id = sc.nextInt();
        String ii = sc.nextLine();
        for (Category list_of_category : list_of_categories) {
            if (list_of_category.id == category_id) {
                list_of_category.add_product();
                break;
            }
        }
    }

    @Override
    public void add_giveaway() {
        System.out.println("Please enter 2 products you want to combine for the deal:- ");

        System.out.println("Product ID one:- ");
        float id1 = sc.nextFloat();
        String gg = sc.nextLine();
        System.out.println("Enter product-1 name:- ");
        String name1 = sc.nextLine();

        System.out.println("Product ID two:- ");
        float id2 = sc.nextFloat();
        String gg1 = sc.nextLine();
        System.out.println("Enter product-2 name:- ");
        String name2 = sc.nextLine();

        Product new_deal = new Product();
        new_deal.disc_prime = 0;
        new_deal.disc_elite = 0;

        float combined_price = 0;
        for (int i = 0; i < Flipzon.list_of_every_product.size(); i++) {
            if (Flipzon.list_of_every_product.get(i).id == id1) {
                combined_price = combined_price + Flipzon.list_of_every_product.get(i).get_elite_price();
                new_deal.p1 = Flipzon.list_of_every_product.get(i);
                break;
            }
        }
        for (int i = 0; i < Flipzon.list_of_every_product.size(); i++) {
            if (Flipzon.list_of_every_product.get(i).id == id2) {
                combined_price = combined_price + Flipzon.list_of_every_product.get(i).get_elite_price();
                new_deal.p2 = Flipzon.list_of_every_product.get(i);
                break;
            }
        }
        System.out.println("There discounted combined price is " + combined_price);
        System.out.println("Enter a price lesser than the combined price for Elite:- ");
        float price = sc.nextFloat();

        System.out.println("Enter a price lesser than the combined price for Prime:- ");
        float price1 = sc.nextFloat();

        System.out.println("Enter a price lesser than the combined price for Normal:- ");
        float price2 = sc.nextFloat();

        System.out.println("Enter an ID for this Deal:- ");
        float id_deal = sc.nextFloat();
        String gg2 = sc.nextLine();

        Flipzon.list_of_deals.add(new_deal);
        new_deal.elite_deal_price = price;
        new_deal.prime_deal_price = price1;
        new_deal.normal_deal_price = price2;

        new_deal.id = id_deal;
        new_deal.name = "Deal";
        new_deal.info = "The products in this deal are " + name1 + " & " + name2;
        Flipzon.list_of_every_product.add(new_deal);
    }

    @Override
    public void set_discount() {
        System.out.println("Enter the Product ID:- ");
        float id = sc.nextFloat();
        int id1 = (int) id;
        for (int i = 0; i < list_of_categories.size(); i++) {
            if (list_of_categories.get(i).id == id1) {
                for (int j = 0; j < list_of_categories.get(i).list_of_products.size(); j++) {
                    if (list_of_categories.get(i).list_of_products.get(j).id == id) {
                        System.out.println("Please enter the discount for Elite customer:- ");
                        float disc1 = sc.nextFloat();
                        if (disc1 > 10) {
                            list_of_categories.get(i).list_of_products.get(j).disc_elite = disc1;
                        }

                        System.out.println("Please enter the discount for Prime customer:- ");
                        float disc2 = sc.nextFloat();
                        String gg12 = sc.nextLine();
                        if (disc2 > 5) {
                            list_of_categories.get(i).list_of_products.get(j).disc_prime = disc2;
                        }

                        System.out.println("Please enter the discount for Normal customer:- ");
                        list_of_categories.get(i).list_of_products.get(j).disc_normal = sc.nextFloat();
                    }
                }
            }
        }
    }

    void delete_category() {
        System.out.println("Enter the category ID:- ");
        int dc = sc.nextInt();
        String gg = sc.nextLine();
        Category selected = new Category();
        for (int l = 0; l < list_of_categories.size(); l++) {
            if (list_of_categories.get(l).id == dc) {
                selected = list_of_categories.get(l);
                break;
            }
        }
        for (int g = 0; g < selected.list_of_products.size(); g++) {
            Flipzon.list_of_every_product.remove(selected.list_of_products.get(g));
        }
        list_of_categories.remove(selected);
    }

    void delete_product() {
        System.out.println("Enter the Product ID:- ");
        float dc = sc.nextFloat();
        String gg = sc.nextLine();
        Product selected = new Product();
        Product selected1 = new Product();
        for (int l = 0; l < Flipzon.list_of_every_product.size(); l++) {
            if (Flipzon.list_of_every_product.get(l).id == dc) {
                selected = Flipzon.list_of_every_product.get(l);
                break;
            }
        }
        list_of_every_product.remove(selected);
        for(int uo = 0; uo<list_of_categories.size() ; uo++){
            for(int a = 0; a<list_of_categories.get(uo).list_of_products.size() ; a++){
                if(list_of_categories.get(uo).list_of_products.get(a).id == dc){
                    selected1 = list_of_categories.get(uo).list_of_products.get(a);
                    list_of_categories.get(uo).list_of_products.remove(selected1);
                    for(int v = 0; v<list_of_deals.size(); v++){
                        if(list_of_deals.get(v).p1 == selected1 || list_of_deals.get(v).p2 == selected1){
                            list_of_every_product.remove(list_of_deals.get(v));
                            list_of_deals.remove(v);
                        }
                    }
                    break;
                }
            }
        }
        
    }
}